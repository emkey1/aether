# Aether for LLMs: small-context guide

*Guide version: 2026-10-26-2*

Dense reference for code-writing models. [CODE] is the compiler's diagnostic code; → is the fix. Every code block compiles.

## Rules
- FX-001: every effectful call sits inside fx { ... }: println/print, files, stdin, env, args, random, clock_ms, http_*, socket_*, sqlite_*, task_*, ai_chat, sleep, toon_parse_file. Pure Text/math/array/conversion builtins need no fx. if/loop nest freely inside fx: fx { loop i in 0..n { println(i); } }. A @pure fn calls only pure builtins and other @pure fns.
- SYN-001: keywords fn let const ret if else loop type mod use fx par. Never return class var def func => or let mut (every let is mutable). while/for compile; loop is canonical. Field and method names may not be keywords (new for if loop ret) or operator words (div mod xor and or not).
- BUILT-001: call only builtins named here; never invent helpers (substring, to_upper, s.upper()). Builtin names are snake_case. [BUILT-002] right name, wrong argument count: format_float(r, 2) takes 1-2 args.
- SCOPE-001: declare before use, in scope at the use site. In a method a field is self.f and a sibling method self.m(); methods do not capture outer locals, so pass them as parameters (METH-001). A method local may share a field's name: v is the local, self.v the field (FIELD-001). The hint names the missing builtin's real name.
- NAME-001: names are case-sensitive and may not differ only by case. Never redeclare a local or parameter, give a loop variable the name of a variable in scope, or name a local after a const (limit beside LIMIT). A later loop may reuse a loop variable's name.
- TYPE-001: annotate unless obvious. Inferred: literals, new T, calls with a documented return type. Always annotate array literals: let xs: Int[] = [1, 2]. Also TYPE-001: println(array), int(text), a Real where an Int is needed (%, div, index, range bound). / is always Real; Int quotient is a div b (7 div 2 = 3).
- TYPE-002: an unknown type name → Int Real Text Bool Void T[] or your own type. Float and String are accepted; Double Integer Boolean Char List Dict int are errors.
- FLOW-001: a non-Void fn returns a value on every path. FLOW-002: bare ret; only in -> Void.
- FIELD-002: use the exact declared field name. FIELD-003: a field default is a literal (count: Int = 0, xs: Int[] = []), never an expression, const, other field, self or call → set it at construction with new T { f: v }.
- FUNC-001: functions are not values: no lambdas, map/filter/reduce, or fn arguments; use loop. A fn nested in a free fn may read and assign that fn's parameters and earlier locals; inside a method it is FUNC-001.
- TUP-001: destructure a direct call, let (a, b) = f();, or bind and read fields, let t = f(); t.0 (0-based); never f().0. A tuple fn may ret g(x) when g returns the same tuple. From a method or expression, return a record instead. A tuple @post reads result.0.
- ANN-001: @pre @post @pure @cost go directly above the fn, each with an expression. @post may name result; on an array compare a property: @post length(result) > 0, @pre all x in xs: x >= 0. @cost 5ms (units ns us ms s op ops step steps) is checked but not enforced.
- IMP-001 MOD-001 MOD-002: use "module_name"; at the file top, only for modules the task provides; it finds module_name or module_name.aether. Call exports by their exact names (labelScore stays labelScore, BaseScore stays BaseScore). A missing module is only a warning, and its names then do not exist. @pure goes above export fn.
- LOOP-001: a loop x in xs body may not change xs → worklist: let i: Int = 0; loop i < len(xs) { ... i = i + 1; }, or loop over a copy.
- ARR-001: arrays are values. A fn that changes an array parameter must return it: xs = f(xs). Dropping a returned array (sorted(xs);) is ARR-001 too. Records are pointer-backed: a callee's changes are visible.
- ARR-002: an Int[] indexed twice → declare Int[][]; build row = row + [v]; then table = table + [row]; bound inner loops with len(table[r]).
- ARR-003 (run time): index out of range. 0..n ends at n - 1; a row is not in the table until appended.
- TOON-001: ToonDoc and ToonNode are opaque handles: no arithmetic, never one for the other; read through toon_root(doc). len of a handle or toon_len of an array (LEN-001) → toon_len(node), len(xs).
- MS-001: MStream is the stream handle (http bodies, socket_receive): mstream_new(), mstream_text(ms) -> Text, mstream_free(ms). Never Int or Text.
- PAR-001 PAR-002: par { f(a); g(b); } runs direct calls in parallel and joins; no assignments or loops inside; each branch writes its own record.
- FMT-001: no placeholders ("{}", %d, f"...") → println("n = ", n). println(a, b) puts nothing between args: println(a, " ", b).
- OUT-001: answer with raw Aether source, no Markdown fences. Match the required output exactly: labels, spacing, casing, line order, decimals; no extra text. Compute results; never hard-code expected output.
- PREC-001: & | ^ xor << >> bind looser than comparisons: (flags & mask) != 0. 0 <= i < n is an error → 0 <= i && i < n.
- DIV-002: // starts a comment; Int division is a div b.
- ENTRY-001: top-level statements (calls, assignments, loops, fx) beside fn main → move them into fn main() -> Void, or end the file with main();. Top-level let and const are fine.
- REC-001: == on a type that contains itself → same(a, b).
- NARROW-001 (warning): a Real stored in an Int truncates; write int(x) if meant. random() is a Real in [0,1), random(n) an Int in [0,n).
- PARAM-001 (warning): parameters are copies; return the moved value: let (v, next) = f(s, pos); pos = next;
- CON-001 (run time): a @pre failed (bad argument) or a @post failed (wrong result).
- Not checked by the compiler: ROOT-001 (JSON starting with { : extract the named array with toon_key before iterating; iterate root only for [), KEY-001 (copy JSON keys exactly, never flatten), NEST-001 (handle a missing nested level on purpose).

## Core syntax
Types: Int (64-bit), Real, Text, Bool (true false), Void, ToonDoc ToonNode MStream. // line comments. Text escapes \" \\ \n \t é. Number separators 1_000_000. Operators + - * / % == != < <= > >= ! && || (not and or are synonyms); -7 % 2 is -1. Arrays, records and tuples compare by value with ==. Every fn declares -> Type; a Void fn ends with ret;.

```aether
const LIMIT: Int = 3;

fn minMax(a: Int, b: Int) -> (Int, Int) {
    ret (min(a, b), max(a, b));
}

fn grade(score: Int) -> Text {
    if score >= 90 {
        ret "A";
    }
    ret if score >= 80 { "B" } else if score >= 70 { "C" } else { "D" };
}

fn main() -> Void {
    let (lo, hi) = minMax(9, 4);
    let t = minMax(7, 5);
    let total: Int = 0;
    loop i in 0..LIMIT { total = total + i; }
    fx { println(lo, " ", hi, " ", t.1, " ", total, " ", grade(85)); }
    ret;
}
```

```aether
loop i in 0..count { }                      // 0 to count-1; 1 through n is 1..n + 1
loop i in 10..0 step -2 { }                 // bounds and step read once
loop item in xs { }                         // array, Text (each char) or ToonNode array
loop index < total { index = index + 1; }   // while form
loop { break; }                             // continue works too
```

all x in xs: x > 0 and any i in 0..n: xs[i] == 0 are Bool expressions (empty: all true, any false).

## Records
```aether
type Counter {
    value: Int;            // fields end with ;

    fn bump() -> Int {
        self.value = self.value + 1;   // lowercase self, never Self
        ret self.value;
    }

    fn bumpTwice() -> Int {
        self.bump();                   // a sibling method needs self. too
        ret self.bump();
    }
}
```

```aether
let p: Point = new Point { x: 3, y: 4 };   // unset fields: default, else 0 0.0 false ""
let q: Point = new Point();
q.x = p.x;
let ps: Point[] = [p, new Point { x: 1, y: 2 }];
```
Methods live inside the type; self is implicit, never a parameter. No fn new, __init__ or T.new(). A top-level fn bump(self: Counter) is an extension method called as c.bump().

## Text and printing
Text indexes like an array: s[0] first char, s[a..b] half-open slice, s[i] = "x" replaces one char, len(s) characters.
```aether
let parts: Text[] = split("12,7,5", ",");
let first: Int = parse_int(parts[0]);         // "12x" -> 12, "abc" -> 0
let (v, good) = try_parse_int(" 42");         // (42, true); whole text must parse
let r: Real = parse_float("3.5");
let label: Text = int_to_text(99) + " " + format_float(3.14159, 2);   // "99 3.14"
let c: Int = ord("A");                        // 65; chr(65) is "A"
let sub: Text = s[1..3];
fx { println("Drop ", j, " -> ID: ", tx.id, " ", pct:0:2); }   // pct:0:2 only in println
```
Text helpers (pure; positions 0-based, -1 if absent): contains starts_with ends_with index_of count upper lower trim replace(s, old, new) repeat(s, n) reversed join(parts, sep) split real_to_text parse_bool. int(x) casts Real/Bool only; use parse_int for numeric text and ord for char codes. println(real) prints the shortest form (2.5, 100.0); format_float(x, 2) or x:0:2 for fixed decimals. Maps: let m: Map[Text, Int] = {}; m[k] = v; m[k] (key must exist), has(m, k), get(m, k, 0), remove(m, k), keys(m), loop k in m (insertion order).

## Math
Real args/results unless noted: sqrt sqr pow(b, e) exp ln log10 sin cos tan arcsin arccos arctan atan2(y, x) cotan sinh cosh tanh; round trunc floor ceil -> Int; abs min max clamp(x, lo, hi) odd(n) factorial fibonacci. Pascal names: arctan not atan, ln not log.

## Arrays
```aether
xs = xs + [7];                 // append; xs + ys concatenates
let size: Int = len(xs);
xs[0] = 9;
let mid: Int[] = ys[0..2];     // copy of elements 0 and 1; also xs[1..], xs[..2]
let zeros: Int[] = [0; n];
let top: Int[] = sorted_desc(ys);
```
Pure helpers returning new values: sum min_of max_of sorted sorted_desc reversed contains index_of count, sorted_by(rs, "field") sorted_by_desc. Print an array by looping over it.

## TOON (JSON)
Helpers: has_toon() toon_parse(text) toon_parse_file(path) (fx) toon_root(doc) toon_close(doc) toon_key(node, key) toon_key_or(node, key, toon_null()) toon_at(node, i) toon_len(node) toon_get_text/int/real/bool(node, key) toon_get_text_or/int_or/real_or/bool_or(node, key, fallback) toon_text/int/real/bool/null_value(node) toon_type toon_has_key toon_has_at toon_is_text/int/real/bool/null/arr/obj toon_free(node). Field getters have no _value suffix; node values do. Keys are Text and may be dotted ("server.port", objects only). A missing level degrades to the fallback, never crashes. toon_close(doc) frees every node from it; toon_free(node) frees one early. Never JsonDoc, json.parseFile, root.get, value.toString().

```aether
// JSON starts with '[': root IS the array
loop i in 0..toon_len(root) {
    let row: ToonNode = toon_at(root, i);
}

// JSON starts with '{': extract the named array first
let jobs: ToonNode = toon_key(root, "jobs");
loop i in 0..toon_len(jobs) {
    let job: ToonNode = toon_at(jobs, i);
}
```

```aether
fn main() -> Void {
    if !has_toon() {
        fx { println("structured data support unavailable"); }
        ret;
    }

    let doc: ToonDoc = toon_parse("{\"rows\":[{\"meta\":{}},{\"meta\":{\"code\":\"K7\"}},{\"note\":\"x\"}]}");
    let root: ToonNode = toon_root(doc);
    let rows: ToonNode = toon_key(root, "rows");
    let missing: Int = 0;

    loop i in 0..toon_len(rows) {
        let row: ToonNode = toon_at(rows, i);
        let code: Text = "EMPTY";
        if toon_has_key(row, "meta") {
            let meta: ToonNode = toon_key(row, "meta");
            code = toon_get_text_or(meta, "code", "EMPTY");
        }
        if code == "EMPTY" {
            missing = missing + 1;
        }
        fx {
            println("row ", i, " = ", code);
        }
    }

    fx {
        println("missing = ", missing);
    }

    toon_close(doc);
    ret;
}
```
Large reports: parse, toon_root, toon_key the array, pure normalize and classify helpers, one totals record, one loop that extracts, classifies, updates and prints, then toon_close.

## Contracts, modules, templates
```aether
@pre score >= 0
@post result >= 0
fn normalize(score: Int) -> Int {
    ret score;
}
```

```aether
use "geometry";

fn main() -> Void {
    let value: Int = area(3, 4);
    fx {
        println(value);
    }
    ret;
}
```

```aether
@pure
fn transform(value: Int) -> Int {
    ret value + 1;
}

fn main() -> Void {
    let answer: Int = transform(41);
    fx {
        println("answer = ", answer);
    }
    ret;
}
```

## Host index (all effectful: inside fx; none in @pure)
Files: read_file(p) -> Text, read_lines(p) -> Text[], write_file(p, t), append_file(p, t), file_exists(p) -> Bool, delete_file(p) -> Bool, rename_file(a, b) -> Bool, mkdir(p), get_current_dir() -> Text; checked: try_read_file(p) -> (Text, Bool), try_read_lines, try_toon_parse_file(p) -> (ToonDoc, Bool). Stdin: read_line() -> Text ("" at end), read_all_stdin(). Env: args() -> Text[], get_env(n) -> Text, get_env_int(n, fallback). Clock: clock_ms() -> Int, now_text() -> Text. sleep(ms). random(), random(n), randomize().
HTTP: http_session() -> Int, http_set_header(s, name, value), http_request(s, method, url, body, out: MStream) -> Int status, http_close(s); read the body with mstream_text(out); JSON body: toon_parse(mstream_text(out)).
Sockets: socket_create(0 TCP | 1 UDP) -> Int, socket_connect(s, host, port), socket_bind(s, port), socket_listen(s, backlog), socket_accept(s) -> Int (blocks), socket_receive(s, maxlen) -> MStream (blocks; empty = closed), socket_send(s, data), socket_close(s), socket_set_blocking(s, b), socket_poll(s, ms, 1 read | 2 write) -> Int, dns_lookup(host) -> Text. Run a client and server pair with par after bind and listen.
SQLite: sqlite_open(path) -> Int (handles count from 0; a failed open stops the program), sqlite_exec, sqlite_prepare, sqlite_step (100 row, 101 done), sqlite_errmsg(db); checked: let (rc, ok) = try_sqlite_exec(db, sql).
Tasks and AI: task_spawn(target, name, arg) -> Int, task_wait(t), task_status(t) (after it finishes, before task_wait), task_result(t); ai_chat(model, messages, system = "", apiKey = "", endpoint = "") -> Text. Pure probes: has_ai(), has_builtin(category, function).
Unlisted builtins: builtins_json(), builtin_info(name) at run time; when writing in one shot never guess an unlisted name.
